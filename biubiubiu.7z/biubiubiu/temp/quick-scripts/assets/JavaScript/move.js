(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/JavaScript/move.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '21b0bJMJCBAab3lmcCtgQmP', 'move', __filename);
// JavaScript/move.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

        acc: 0,
        player: {
            default: null,
            type: cc.Node
        },
        moveSpeed: 0,
        AI: false

    },

    onLoad: function onLoad() {
        this.accTop = false;
        this.accBot = false;
        this.accLeft = false;
        this.accRight = false;
        if (this.AI) {
            this.setInputControl();
        }
    },

    setInputControl: function setInputControl() {
        var self = this;
        var listener = {
            event: cc.EventListener.KEYBOARD,
            onKeyPressed: function onKeyPressed(keyCode, event) {
                switch (keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        self.accLeft = true;
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        self.accRight = true;
                        break;
                    case cc.KEY.w:
                    case cc.KEY.up:
                        self.accTop = true;
                        break;
                    case cc.KEY.s:
                    case cc.KEY.down:
                        self.accBot = true;
                        break;
                }
            },
            onKeyReleased: function onKeyReleased(keyCode, event) {
                switch (keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        self.accLeft = false;
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        self.accRight = false;
                        break;
                    case cc.KEY.w:
                    case cc.KEY.up:
                        self.accTop = false;
                        break;
                    case cc.KEY.s:
                    case cc.KEY.down:
                        self.accBot = false;
                        break;
                }
            }
        };
        cc.eventManager.addListener(listener, self.node);
    },

    onDisable: function onDisable() {
        cc.director.getCollisionManager().enabled = false;
        cc.director.getCollisionManager().enabledDebugDraw = false;
    },

    update: function update(dt) {
        if (this.accLeft) {
            this.player.x -= this.acc;
        }
        if (this.accRight) {
            this.player.x += this.acc;
        }
        if (this.accTop) {
            this.player.y += this.acc;
        }
        if (this.accBot) {
            this.player.y -= this.acc;
        }
        if (!this.AI) {
            var targetVector = cc.pSub(cc.find('root/hero').position, this.node.position);
            var moveStep = cc.pMult(cc.pNormalize(targetVector), this.moveSpeed);
            if (moveStep.x > 0 && !!this._rightBlock) {
                moveStep.x = 0;
            }
            if (moveStep.x < 0 && !!this._leftBlock) {
                moveStep.x = 0;
            }
            if (moveStep.y > 0 && !!this._upBlock) {
                moveStep.y = 0;
            }
            // if(moveStep.y < 0 && !!this._downBlock){moveStep.y = 0;}
            // if(moveStep.x > 0){this.node.scaleX = 1;this.node.children[0].scaleX = 1;}
            // if(moveStep.x < 0){this.node.scaleX = -1;this.node.children[0].scaleX = -1;}
            this.node.position = cc.pAdd(this.node.position, moveStep);
        } else {

            if (this._left && !this._leftBlock) {
                this.node.x -= this.moveSpeed;
            }
            if (this._right && !this._rightBlock) {
                this.node.x += this.moveSpeed;
            }
            if (this._up && !this._upBlock) {
                this.node.y += this.moveSpeed;
            }
            if (this._down && !this._downBlock) {
                this.node.y -= this.moveSpeed;
            }
        }
    }

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=move.js.map
        