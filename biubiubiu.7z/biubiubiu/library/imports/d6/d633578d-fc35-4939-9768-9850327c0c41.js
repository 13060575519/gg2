"use strict";
cc._RF.push(module, 'd6335eN/DVJOZdomFAyfAxB', 'shoot');
// JavaScript/shoot.js

'use strict';

// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        bullet: {
            default: null,
            type: cc.Node
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        var canvas = cc.find('Canvas');
        canvas.on(cc.Node.EventType.TOUCH_START, this.onTouchBegan, this);
    },
    onTouchBegan: function onTouchBegan(event) {
        var scene = cc.director.getScene();
        var touchLoc = event.touch.getLocation();
        var touchV2 = cc.v2(touchLoc.x, touchLoc.y);
        var playerPos = cc.find('root/hero').position;
        var bullet = cc.instantiate(this.bullet);
        bullet.position = playerPos;
        //bullet.active = true;
        scene.addChild(bullet);
        //计算 玩家与鼠标 两点向量, 归一化得到方向后，点乘1000获得射击距离，
        //最后moveBy每次子弹匀速朝该方向运动
        var v2Bullet = cc.pMult(cc.pNormalize(cc.pSub(touchV2, playerPos)), 1500);
        bullet.runAction(cc.moveBy(3, v2Bullet));
    },

    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();