"use strict";
cc._RF.push(module, 'cc4d29p15VKWImRu+NgIrNK', 'player');
// JavaScript/player.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {

        player: {
            default: null,
            type: cc.Node
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    onCollisionEnter: function onCollisionEnter(other) {
        if (other.node.group === 'enemy') {
            this.node.destroy();
            console.log('1');
        }
    }
}

// update (dt) {},
);

cc._RF.pop();