"use strict";
cc._RF.push(module, '9d61dRYsjZB/JZjWt6bNT5A', 'hp-data');
// JavaScript/hp-data.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        hp: 100,
        AI: false,
        hurtValue: 5,
        hpLabel: {
            default: null,
            type: cc.Label

        },

        hurtDurationOfEnemyTouch: 0.5, //just use in enemy
        _hurtTimeStamp: null,
        _enemyRemoving: false,
        _sceneLoading: false
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {

        this._hurtTimeStamp = Date.now();

        this.hpLabel.string = this.hp;
    },

    onCollisionStay: function onCollisionStay(other, self) {
        if (this.AI && other.node.group == 'enemy') {

            if (this._hurtTimeStamp + this.hurtDurationOfEnemyTouch * 1000 <= Date.now()) {
                this.onHurt();
                this._hurtTimeStamp = Date.now();
            }
        }
    },

    onHurt: function onHurt() {
        this.hp -= this.hurtValue;
        if (this.hp <= 0) {
            if (this.AI) {
                //game over
                if (!this._sceneLoading) {
                    this._sceneLoading = true;
                    cc.director.loadScene('gameover');
                }
            } else {
                //enemy removed
                if (!this._enemyRemoving) {
                    this._enemyRemoving = true;
                    window.enemyNum--;
                    this.node.removeFromParent();
                }
            }
        } else {
            this.hpLabel.string = this.hp;
        }
    }

});

cc._RF.pop();