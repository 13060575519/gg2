
cc.Class({
    extends: cc.Component,

    properties: {
        
        player: {
            default: null,
            type: cc.Node,
        },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },
    onCollisionEnter (other) {
        if (other.node.group === 'enemy') {
            this.node.destroy();
           console.log('1') 
        }
    },

    // update (dt) {},
});
